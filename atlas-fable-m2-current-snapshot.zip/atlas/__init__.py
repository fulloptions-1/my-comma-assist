"""Atlas automation engine."""
